# Journal JS
Simple personal journal built with vanilla JavaScript. Local Storage is used to save entries.

## Features
* Add entries
* Delete entry
* See added date
* Simple layout

---

> Feel free to contribute and/or modify.
