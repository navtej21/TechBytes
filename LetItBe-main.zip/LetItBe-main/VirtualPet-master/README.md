# Virtual Pet

Virtual Pet developed in JavaScript.

![alt screenshot](https://raw.githubusercontent.com/lrusso/VirtualPet/master/VirtualPet.png)

## Web:

https://lrusso.github.io/VirtualPet/VirtualPet.htm
